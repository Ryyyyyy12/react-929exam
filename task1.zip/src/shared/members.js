export const MEMBERS = [
    {
        id:0,
        name: "Lisa",
        fullname:"Lalisa Manobal",
        image: '/assets/images/lisa.jpg',
        description:"Lalisa Manobal, known mononymously as Lisa, is a Thai rapper, singer and dancer based in South Korea."
    },
    {
        id:1,
        name: "Jennie",
        fullname:"Jennie Kim",
        image: '/assets/images/jennie.jpg',
        description:"Jennie Kim, known mononymously as Jennie, is a South Korean singer and rapper."
    },
    {
        id:2,
        name: "Jisoo",
        fullname:"Kim Ji-soo",
        image: '/assets/images/jisoo.jpg',
        description: "Kim Ji-soo, known mononymously as Jisoo, is a South Korean singer and actress. "
    },
    {
        id:3,
        name: "Rose",
        fullname:"Roseanne Park",
        image: '/assets/images/rose.jpg',
        description:"Roseanne Park, known mononymously as Rosé, is a Korean-New Zealand singer and dancer based in South Korea."
    }
];